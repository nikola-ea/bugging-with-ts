
import { Todos } from './Todos';

function App() {
  return (
    <div>
      <h1>Todo List</h1>
      <Todos />
    </div>
  );
}

export default App;
